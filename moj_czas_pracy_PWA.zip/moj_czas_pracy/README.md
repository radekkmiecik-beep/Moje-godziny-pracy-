# Mój czas pracy — darmowa aplikacja PWA

## Co potrafi?
- Liczy czas od rozpoczęcia do zakończenia pracy; **przerwy są wliczane**.
- Ustawia stawkę godzinową.
- Pokazuje dzisiejszy i miesięczny czas oraz szacowane zarobki.
- Pozwala dodać wpis ręcznie, usuwać wpisy i eksportować raport miesiąca do CSV.
- Działa na telefonie i komputerze. Dane pozostają w pamięci przeglądarki na danym urządzeniu.

## Najprostsze darmowe uruchomienie przez GitHub Pages
1. Zaloguj się lub załóż konto na https://github.com/
2. Utwórz nowe repozytorium, np. `moj-czas-pracy`.
3. Wgraj do repozytorium pliki `index.html`, `manifest.json` i `service-worker.js` (możesz też wgrać cały folder).
4. W repozytorium otwórz **Settings → Pages**.
5. W sekcji budowania wybierz **Deploy from a branch**, gałąź `main` i folder `/ (root)`, a następnie zapisz.
6. Po chwili GitHub pokaże adres strony. Otwórz go na telefonie.

## Dodanie do ekranu głównego
- **iPhone:** otwórz stronę w Safari → Udostępnij → „Dodaj do ekranu początkowego”.
- **Android:** otwórz stronę w Chrome → menu ⋮ → „Zainstaluj aplikację” lub „Dodaj do ekranu głównego”.

## Ważne
- To wersja startowa — nie wymaga płatnego serwera ani logowania.
- Dane są lokalne: nie synchronizują się automatycznie między telefonami i mogą zniknąć po wyczyszczeniu danych przeglądarki. Eksportuj CSV jako kopię.
- Zarobki są szacunkiem: stawka jest jedna dla wszystkich wpisów i nie uwzględnia podatków, nadgodzin ani dodatków.
